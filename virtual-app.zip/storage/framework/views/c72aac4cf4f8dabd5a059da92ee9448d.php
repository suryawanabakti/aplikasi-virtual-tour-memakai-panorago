
<?php $__env->startSection('content'); ?>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Web Profile</h4>
                </div>
                <div class="card-body">
                    <form action="/setting" method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="" class="form-label">Judul</label>
                            <input type="text" class="form-control" required name="title"
                                value="<?php echo e($setting->title); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">About</label>
                            <input type="text" class="form-control" required name="about"
                                value="<?php echo e($setting->about); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Deskripsi</label>
                            <input type="text" class="form-control" required name="deskripsi"
                                value="<?php echo e($setting->deskripsi); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">No. Telepon</label>
                            <input type="text" class="form-control" required name="no_telepon"
                                value="<?php echo e($setting->no_telepon); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Email</label>
                            <input type="text" class="form-control" required name="email"
                                value="<?php echo e($setting->email); ?>">
                        </div>

                        <button class="btn btn-primary" type="submit">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\virtual-tour\resources\views/admin/web/index.blade.php ENDPATH**/ ?>