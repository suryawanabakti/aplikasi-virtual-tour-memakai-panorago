<?php

namespace Cwin\BasicWord\WordProcessing\Source;

interface WordFactoryInterface
{
	public function sourceBaseWord();

	public function sourceBaseWordArr();
}